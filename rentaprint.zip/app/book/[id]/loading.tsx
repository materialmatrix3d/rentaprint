export default function Loading() {
  return <p>Loading booking page...</p>;
}
