'use client';
export default function MyPrinters() {
  return (
    <main className="p-4">
      <h1 className="text-2xl font-bold mb-4">My Printers</h1>
      <p>You haven't listed any printers yet. More tools for managing your printers coming soon!</p>
    </main>
  );
}
