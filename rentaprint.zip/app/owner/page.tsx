'use client';
export default function OwnerPanel() {
  return (
    <main className="p-4">
      <h1 className="text-2xl font-bold mb-4">Owner Panel</h1>
      <p>Welcome to the Owner Panel. Tools to manage printers and bookings coming soon!</p>
    </main>
  );
}
