import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { auth } from '@clerk/nextjs/server';
import { bookings, printers } from '@/lib/schema';
import { eq } from 'drizzle-orm';

export async function POST(req: Request) {
  const { userId } = auth();
  const body = await req.json();
  const { printerId, hours } = body;

  if (!userId) {
    return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
  }

  const printer = await db.query.printers.findFirst({
    where: eq(printers.id, printerId),
  });

  if (!printer) {
    return NextResponse.json({ error: 'Printer not found' }, { status: 404 });
  }

  const totalCost = hours * printer.price_per_hour;

  const booking = await db
    .insert(bookings)
    .values({
      clerk_user_id: userId,
      printer_id: printerId,
      hours,
      total_cost: totalCost,
    })
    .returning();

  return NextResponse.json(booking);
}