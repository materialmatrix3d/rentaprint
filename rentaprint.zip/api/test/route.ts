export async function GET() {
  return new Response("✅ API routing is working", { status: 200 });
}
